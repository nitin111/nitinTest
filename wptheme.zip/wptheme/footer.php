<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #page div elements.
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */
?>

<!--Info text pan-->
<div class="info-text">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<i class="info-icon"></i>
				Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent porttitor imperdiet dolor, nec tempus magna egestas dignissim. Nunc blandit et urna ut auctor....</div>
		</div>
	</div>
</div>
<!--/Info text pan-->

<!--DIDACTITIEL pan-->
<div class="text-center">
	<a href="javascript:void(0);">
		<img src="<?php echo get_template_directory_uri(); ?>/images/didactitiel.png" alt="Didactitiel" title="Didactitiel">
	</a>
</div>
<!--/DIDACTITIEL pan-->

</div>
<!--/Home body container-->

<!-- jQuery plugins -->
<script src="<?php echo get_template_directory_uri(); ?>/javascripts/jquery.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/javascripts/jquery-migrate.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/components/bootstrap-sass/assets/javascripts/bootstrap.js"></script>

<!--Form-->
<script src="<?php echo get_template_directory_uri(); ?>/components/form-placeholder/classie.js"></script>
<!--/Form-->

<!--Selectbox-->
<script src="<?php echo get_template_directory_uri(); ?>/components/bootstrap-select/js/bootstrap-select.min.js"></script>
<!--/Selectbox-->


<script src="<?php echo get_template_directory_uri(); ?>/javascripts/custom.js" type="text/javascript"></script>

<?php wp_footer(); ?>
</body>
</html>