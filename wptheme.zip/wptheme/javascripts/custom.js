// JavaScript Document
$(document).ready(function(){
	//Form
	(function() {
		// trim polyfill : https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/Trim
		if (!String.prototype.trim) {
			(function() {
				// Make sure we trim BOM and NBSP
				var rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
				String.prototype.trim = function() {
					return this.replace(rtrim, '');
				};
			})();
		}

		[].slice.call( document.querySelectorAll( '.from-flaceholder input.form-control' ) ).forEach( function( inputEl ) {
			// in case the input is already filled..
			if( inputEl.value.trim() !== '' ) {
				classie.add( inputEl.parentNode, 'input-focus' );
			}

			// events:
			inputEl.addEventListener( 'focus', onInputFocus );
			inputEl.addEventListener( 'blur', onInputBlur );
		} );

		function onInputFocus( ev ) {
			classie.add( ev.target.parentNode, 'input-focus' );
		}

		function onInputBlur( ev ) {
			if( ev.target.value.trim() === '' ) {
				classie.remove( ev.target.parentNode, 'input-focus' );
			}
		}
	})();
	
	//Navigation
	$('.navbar-toggle').click(function(){
		if($(this).parent().children('.navbar-pan').css('display')=='none'){
			$(this).addClass('active').parent().children('.navbar-pan').slideDown();
			$('body').prepend('<div class="navigation-overlay"></div>');
		}else{
			$(this).removeClass('active').parent().children('.navbar-pan').slideUp();
			$('.navigation-overlay').remove();
		}
	});
	
	$(document).on( 'click', '.navigation-overlay', function() {
		$('.main-menu-pan .navbar-toggle').removeClass('active');
		$('.main-menu-pan .navbar-pan').slideUp();
		$('.navigation-overlay').remove();
	});
	
	
	// Selectbox
	$('select.form-control').selectpicker();
	
	//Go top button
	$('.go-top-btn').click(function(){
		var	topPosition	=	$(this).parents('.accordion-panel').children('.panel-heading').offset().top;
		
		$('body,html').animate({scrollTop: topPosition}, 800);
		return false;
		
	});
	

});
/**************************Document.ready end**************************/












