<?php
/**
 * Template Name: Front Page
 */
get_header();
?>

<!--Banner Part-->
<figure class="banner-part"></figure>
<!--/Banner Part-->

<!--Home body container-->
<div class="home-body-container">

    <div class="container">
        <div class="row">
            <!--Left part-->
            <div class="col-md-8">
                <?php dynamic_sidebar('sidebar-4');  ?>
                
            </div>
            <!--/Left part-->

            <!--right part-->
            <section class="col-md-4">
                <h2 class="search-heading">Recherche client</h2>
                <section class="right-search-container">
                    <form action="#" method="post">
                        <div class="form-group from-flaceholder">
                            <input type="text" class="form-control">
                            <label class="placeholder-label">Nom</label>
                        </div>
                        <span class="error-message">Error message</span>
                        <div class="form-group from-flaceholder">
                            <input type="text" class="form-control">
                            <label class="placeholder-label">Prénom</label>
                        </div>
                        <div class="form-group from-flaceholder">
                            <input type="text" class="form-control" >
                            <label class="placeholder-label">Date de naissance</label>
                        </div>

                        <div class="or-text">
                            <span>OU</span>
                        </div>

                        <div class="form-group from-flaceholder">
                            <input type="text" class="form-control">
                            <label class="placeholder-label">N° de client / dossier</label>
                        </div>
                        <div class="home-search-button">
                            <button type="button" class="btn white-button">EFFACER LES CHAMPS</button>
                            <button type="button" class="btn black-button">RECHERCHER</button>
                        </div>
                    </form>
                </section>
            </section>
            <!--/right part-->

        </div>
    </div>



  <?php
get_footer();

?>
